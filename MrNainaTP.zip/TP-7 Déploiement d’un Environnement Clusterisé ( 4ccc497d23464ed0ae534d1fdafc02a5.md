# TP-7: Déploiement d’un Environnement Clusterisé (1)

Propriétaire: Nomena Lebreton

<aside>
💡 La réplication "Master-to-Master" est un modèle de réplication de bases de données où deux serveurs maîtres, généralement situés dans des emplacements physiques différents, sont configurés pour se copier mutuellement les données. Ce modèle est également connu sous le nom de "réplication bidirectionnelle".

</aside>

---

- Master
    
    La réplication maître-maître MySQL, parfois appelée réplication bidirectionnelle, est un mécanisme de synchronisation de données entre deux serveurs MySQL, où chaque serveur peut agir à la fois en tant que maître et esclave. Cela signifie que chaque serveur a le pouvoir d'écrire des données (comme un maître) et de recevoir des mises à jour provenant de l'autre serveur (comme un esclave). Ce type de réplication est souvent utilisé pour assurer la disponibilité élevée et la tolérance aux pannes dans les systèmes de bases de données MySQL. Voici comment cela fonctionne :
    
    1. **Écriture simultanée :** Avec la réplication maître-maître, les deux serveurs peuvent accepter des écritures simultanées. Cela signifie que vous pouvez insérer, mettre à jour ou supprimer des données sur n'importe lequel des serveurs, et ces modifications seront répliquées vers l'autre serveur.
    2. **Réplication bidirectionnelle :** Chaque serveur agit à la fois en tant que source (maître) et cible (esclave) pour les données. Les modifications effectuées sur un serveur sont répliquées vers l'autre, et vice versa. Cela permet de maintenir la cohérence des données entre les deux serveurs.
    3. **Conflits :** L'une des principales préoccupations dans la réplication maître-maître est la gestion des conflits. Si les mêmes données sont modifiées de manière conflictuelle sur les deux serveurs en même temps, un conflit peut se produire. La résolution de ces conflits peut nécessiter une configuration spécifique.
    4. **Latence et bande passante :** La réplication maître-maître peut générer une utilisation intense de la bande passante réseau, car les serveurs s'envoient mutuellement les mises à jour. La latence entre les serveurs peut également être un facteur, en particulier si les mises à jour doivent être propagées rapidement.
    5. **Sécurité :** Comme dans toute réplication, la sécurité est importante. Il est essentiel de configurer l'authentification et, si nécessaire, le chiffrement pour sécuriser la communication entre les serveurs.

---