# G-Class Project : React Js + Spring Boot API REST

Propriétaire: Nomena Lebreton

<aside>
💡 Objectifs : Délai estimé 9 jours

</aside>

---

---

-manao projet

---

---

---