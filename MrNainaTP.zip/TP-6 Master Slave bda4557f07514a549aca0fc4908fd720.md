# TP-6: Master/Slave

Propriétaire: Nomena Lebreton

<aside>
💡 Dans le contexte de la réplication de bases de données, les termes "Master" (maître) et "Slave" (esclave) sont des concepts utilisés pour décrire les différents rôles que jouent les serveurs dans le processus de réplication. La réplication de base de données est le processus de copie et de synchronisation des données d'une base de données d'origine (le maître) vers une ou plusieurs autres bases de données (les esclaves). Voici ce que signifient ces rôles

</aside>

---

- Master
    - Le serveur Master est le serveur source qui détient la copie principale et autoritative des données.
    - Il est responsable de la création, de la mise à jour et de la gestion des données.
- Slave
    - Les serveurs Slave sont des serveurs qui copient et maintiennent une copie des données du serveur Master.
    - Ils sont en mode lecture seule, ce qui signifie qu'ils ne sont pas autorisés à effectuer des opérations de modification de données directes (comme les insertions, les mises à jour ou les suppressions).
    - Les serveurs Slave sont utilisés pour la lecture des données et pour améliorer les performances en distribuant la charge de lecture entre plusieurs serveurs.
    1. Personnaliser l'expérience de l'utilisateur en fonction de ses actions.

---

### **Configuration environnement :**

---

[https://hevodata.com/learn/postgresql-master-slave-replication/](https://hevodata.com/learn/postgresql-master-slave-replication/)

Aperçue configuration Master/Slave : 

![Untitled](Untitled%201.png)

                            R E M A R Q U E S 

- Avant le test , il est plus prudent de tester la connectivité des 2 pcs à travers **`Postgres`**

![Untitled](Untitled%202.png)

---

- Désactiver tous les pare-feu des 2 pcs Master/Slave

---

- Il est préférable d’être super utilisateur en manipulant le terminal Postgresql et cmd pour les configurations

---

- En cas d’erreur après **`CREATE SUBSCRIPTION`**

![Untitled](Untitled%203.png)

⇒ **`\encoding` `utf-8;`**

---

- Il est préférable d’être super utilisateur en manipulant le terminal Postgresql et cmd pour les configurations

---

- C’est dans la base de données du Slave qu’on effectue la **`SUBSCRIPTION` que le Master a fait**

---

Configuration important dans le terminal bin dans le répertoire postgres : 

```bash
⇒ pg_dump -U postgres -d (db iraisana) -t (table iraisana) -f (fichier sql où sauvergarder les scripts)
```

---

```bash
Une fois connecté , poursuivre avec :
psql -U postgres -d (base iraisana) -h (ip Slave) -f (fichier misy anleh base copiena)
```

---

![Untitled](Untitled%204.png)

---

<aside>
💡 Notions cmd  :

</aside>

`'-h' (ou '--host')`  :  spécifier l'adresse IP ou le nom d'hôte du serveur PostgreSQL auquel vous souhaitez vous connecter

---

`'-t' (ou '--tuples-only')` : utilisée avec la commande **`psql`** 

les résultats des requêtes SQL seront affichés sans les en-têtes de colonnes ni les espaces entre les valeurs. Souvent utilisé lorsque vous souhaitez extraire des données de manière plus propre