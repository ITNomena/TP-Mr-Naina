# TP-5 : SessionHandler

Propriétaire: Nomena Lebreton

<aside>
💡  " SessionHandler " : La manipulation des sessions en PHP est généralement appelée "gestion des sessions PHP" ou simplement "sessions PHP". C'est un processus qui permet de stocker des données temporaires côté serveur pour un utilisateur donné, afin de maintenir un état entre les différentes requêtes HTTP .

</aside>

---

- Principal fonction du gestion des sessions en PHP
    1. Gérer l'authentification des utilisateurs.
    2. Stocker des informations utilisateur temporaires (par exemple, un panier d'achat).
    3. Maintenir l'état de l'application entre les pages.
    4. Personnaliser l'expérience de l'utilisateur en fonction de ses actions.

---

### **Objectif du TP :**

> Un système de gestion de sessions en PHP utilisant une base de données PostgreSQL pour stocker les données de session. L'objectif principal est de permettre aux utilisateurs de maintenir leur état et leurs données lorsqu'ils naviguent sur votre site.
> 

---

### **Configuration Requise :**

Avant de lancer le TP, il faut configurer plusieurs éléments :

1. **Serveur Web** : disposer d'un serveur web (par exemple, Apache) configuré pour exécuter des scripts PHP.
2. **PHP** :  disposer d'une installation PHP avec le support de PostgreSQL activé (vérifié via phpinfo).
3. **Base de données PostgreSQL** :  avoir une instance PostgreSQL en cours d'exécution avec des tables appropriées pour stocker les données de session.
4. **Configuration de pg_hba.conf** : Dans le fichier **`pg_hba.conf`** de PostgreSQL, je dois autoriser les connexions à la base de données depuis l'adresse IP du serveur web. Par exemple, ajouter  une ligne comme **`host all all adresse_ip_serveur_web/32 md5`**.
5. **Configuration de php.ini** : Dans le fichier **`php.ini`**, s’assurer que l'extension PDO PostgreSQL est activée (**`extension=php_pdo_pgsql.dll`**) et configurez le chemin vers l'exécutable PostgreSQL dans **`php.ini`**.
6. **Pare-feu** : m’assurer que le pare-feu de mon PC permet la communication sur le port PostgreSQL (par défaut, le port est 5432). Vous devrez ouvrir ce port pour permettre les connexions entrantes à PostgreSQL.

![Untitled](Untitled.png)

1. **Vérifiez la version de PostgreSQL** : m’assuer que la version de PostgreSQL que j’utilise est compatible avec l'extension PDO de ma version PHP.
2. **Vérifiez les erreurs de PostgreSQL** : Consulter les fichiers de logs de PostgreSQL pour voir s'il y a des erreurs ou des messages de journalisation liés à la tentative de connexion.
3. M’assurer **que PostgreSQL accepte les connexions distantes** : Par défaut, PostgreSQL peut ne pas accepter les connexions distantes. Je devrais peut-être modifier la configuration de PostgreSQL pour permettre les connexions distantes.

---

<aside>
💡 Les cookies de session sont utilisés pour suivre et identifier de manière unique chaque utilisateur qui visite votre site. Ils sont essentiels pour la gestion des sessions en PHP, car ils permettent au serveur de savoir quelle session est associée à chaque utilisateur, même lorsque l'utilisateur navigue entre les pages.

</aside>

---

### **Explication des Codes et du Fonctionnement :**

1. **connection.php** :
    - Ce fichier gère la connexion à la base de données PostgreSQL en utilisant la classe PDO. Il configure la connexion avec les informations de connexion (nom d'hôte, port, nom d'utilisateur, mot de passe).
    - En cas d'échec de la connexion, il génère une exception PDO.
2. LaSession**.php** :
    - Ce fichier contient la classe **`LaSession`** , qui implémente l'interface **`SessionHandlerInterface`**.
    - Il est utilisé pour personnaliser la gestion des sessions en utilisant PostgreSQL comme support de stockage.
    - La classe **`LaSession`** gère l'ouverture, la fermeture, la lecture, l'écriture et la destruction des sessions, ainsi que le nettoyage des sessions expirées.
    - Elle établit une connexion à la base de données PostgreSQL dans le constructeur et utilise cette connexion pour stocker et récupérer les données de session.
3. **index.php** :
    - Cette page est la page d'accueil de votre application. Elle utilise **`LaSession`** pour gérer les sessions.
    - Elle permet aux utilisateurs de saisir des données dans un formulaire et de les stocker en tant que données de session.
4. **treatment.php** :
    - Cette page traite les données du formulaire soumises par l'utilisateur et les stocke en tant que données de session en utilisant **`LaSession`** .
    - Ensuite, elle redirige l'utilisateur vers la page "welcome.php".
5. **welcome.php** :
    - Cette page affiche les données de session stockées par l'utilisateur après avoir soumis le formulaire. Elle récupère les données de session à partir de la base de données à l'aide de **`LaSession`** et les affiche à l'utilisateur.
6. **deconnexion.php** :
    - Cette page est destinée à la déconnexion de l'utilisateur. Elle détruit la session en cours en utilisant **`LaSession`** et redirige l'utilisateur vers la page d'accueil.

---

### **Fonctionnement du Système :**

1. Lorsqu'un utilisateur visite la page d'accueil "index.php", il peut saisir des données dans un formulaire.
2. Une fois les données soumises, le script "traitement.php" les stocke en tant que données de session à l'aide de **`LaSession`** .
3. L'utilisateur est ensuite redirigé vers la page "welcome.php", où les données de session sont récupérées à partir de la base de données à l'aide de **`LaSession`** et affichées à l'utilisateur.
4. L'utilisateur peut également se déconnecter en accédant à "deconnexion.php", ce qui détruira la session en cours.

Le système fonctionne en utilisant la classe **`LaSession`** pour gérer la persistance des données de session dans la base de données PostgreSQL. Cela permet aux utilisateurs de conserver leur état et leurs données entre différentes pages de votre application.

<aside>
💡 Vérifier que toutes les configurations préalables (serveur web, PHP, PostgreSQL, pare-feu) sont correctes, et que les fichiers de votre projet sont correctement configurés. En outre, vérifier que les tables PostgreSQL pour les sessions sont correctement définies avec les champs nécessaires (id, data, access).

</aside>

---