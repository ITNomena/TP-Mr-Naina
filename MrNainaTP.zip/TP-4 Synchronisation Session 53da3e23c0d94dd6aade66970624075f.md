# TP-4 :  Synchronisation Session

Propriétaire: Nomena Lebreton

<aside>
💡 HA Proxy :  (High Availability Proxy) est un logiciel Open-source qui agit comme un répartiteur de charge (Load balancer) et un proxy pour les applications web et les services. Son principal objectif est d'assurer la disponibilité, la fiabilité et la performance des applications en répartissant le trafic entre plusieurs serveurs backend.

</aside>

## Configuration et Manipulation

- Configuration du PostgreSQL

---

⇒Modification du fichier ‘pg_hba.conf’ dans un répertoire de l’ordinateur serveur

---

⇒Ajouter une ligne pour autoriser l’accès à distance à la base de donnée PostgreSQL:

```jsx
host    all    all    0.0.0.0/0    md5
```

Example: host all all votre-adresse-ip/32 md5

<aside>
💡 Cette ligne permettra aux clients distants de se connecter à la base de données PostgreSql en utilisant une authentification basée sur un mot de passe (md5)

</aside>

---

⇒Assurer que le paramètre ‘listen_addresses’ dans le fichier ‘postgresql.conf’ :
listen_addresses = ‘*’

⇒CTRL S + Redémarrer

---

- Configuration du pare-feu pour Windows :

Avant de configurer le pare-feu, s’assurer de connaître le numéro de port utilisé par HA Proxy. Par défaut, HA Proxy utilise le port 80 pour le trafic HTTP et le port 443 pour le trafic HTTPS, mais cela peut varier en fonction de votre configuration. Je dois donc déterminer le port exact utilisé par HA Proxy.

---

1. Cliquez sur le bouton "Démarrer" dans Windows .Tapez "Firewall" dans la barre de recherche et sélectionnez "Pare-feu Windows avec fonctions avancées de sécurité".
2. **Configurez la règle du pare-feu** :
    - Dans la fenêtre du Pare-feu Windows avec fonctions avancées de sécurité, cliquez sur "Règles de trafic entrant" dans le volet de gauche.
3. **Créez une nouvelle règle** :
    - Dans le volet de droite, cliquez sur "Nouvelle règle" pour créer une nouvelle règle entrante.
4. **Choisissez le type de règle** :
    - Sélectionnez "Port" comme type de règle et cliquez sur "Suivant".
5. **Spécifiez le numéro de port** :
    - Sélectionnez "TCP" comme type de protocole.
    - Dans "Spécifiez les ports locaux", entrez le numéro de port utilisé par HAProxy.
    - Cliquez sur "Suivant".
6. **Choisissez l'action** :
    - Sélectionnez "Autoriser la connexion" pour permettre le trafic entrant.
    - Cliquez sur "Suivant".
7. **Choisissez le profil** :
    - Sélectionner les profils appropriés pour votre situation. Si vous n'êtes pas sûr, laissez les options par défaut.
    - Cliquez sur "Suivant".
8. **Attribuez un nom à la règle** :
    - Donnez un nom à votre règle, puis ajoutez une description (facultatif).
    - Cliquez sur "Terminer" pour créer la règle.
9. **Vérifiez la règle** :
    - Assurez-vous que la règle que vous venez de créer apparaît dans la liste des règles de trafic entrant.

<aside>
💡 Une fois que la règle est créée, le pare-feu Windows autorisera le trafic entrant sur le port spécifié pour HAProxy.

</aside>

---

- **Configuration du Pare-Feu sous Linux (iptables) :**

La configuration du pare-feu sur Linux dépend du gestionnaire de pare-feu que vous utilisez. Si vous utilisez iptables, voici comment autoriser l'accès à HAProxy :

1. Ouvrez un terminal en tant qu'administrateur (ou utilisez **`sudo`**).
2. Pour autoriser l'accès au port utilisé par HAProxy (par exemple, le port 80 pour HTTP), exécutez la commande suivante :
    
    ```bash
    bashCopy code
    sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT
    
    ```
    
    Cela permet d'accepter les connexions entrantes sur le port 80.
    
3. Pour sauvegarder ces règles, exécutez la commande suivante :
    
    ```bash
    bashCopy code
    sudo iptables-save > /etc/iptables/rules.v4
    
    ```
    

<aside>
💡 Cela enregistre les règles dans un fichier pour qu'elles soient appliquées au démarrage. M’assurer d'adapter ces instructions en fonction de votre configuration spécifique, notamment du port que vous utilisez pour HAProxy. Il est important de comprendre la sécurité de votre environnement et de configurer le pare-feu de manière à ne permettre que le trafic nécessaire.

</aside>

---

- Autre façon de configurer le pare-feu sur linux :

**Configuration du Pare-Feu avec UFW (Uncomplicated Firewall) :**

1. Installez UFW (si ce n'est pas déjà fait) en utilisant votre gestionnaire de paquets. Par exemple, sur Ubuntu, vous pouvez faire :
    
    ```bash
    bashCopy code
    sudo apt-get install ufw
    
    ```
    
2. Activez UFW avec la commande suivante :
    
    ```bash
    bashCopy code
    sudo ufw enable
    
    ```
    
3. Autorisez l'accès au port que vous souhaitez pour HAProxy (par exemple, le port 80 pour HTTP) en utilisant la commande :
    
    ```bash
    bashCopy code
    sudo ufw allow 80/tcp
    
    ```
    
4. Si vous utilisez également HTTPS, autorisez le port 443 de la même manière :
    
    ```bash
    bashCopy code
    sudo ufw allow 443/tcp
    
    ```
    
5. Vous pouvez vérifier les règles actives en utilisant :
    
    ```bash
    bashCopy code
    sudo ufw status
    
    ```
    
6. Assurez-vous que le pare-feu est activé au démarrage avec :
    
    ```bash
    bashCopy code
    sudo systemctl enable ufw
    
    ```
    

**Configuration du Pare-Feu avec Firewalld :**

1. Installez Firewalld (si ce n'est pas déjà fait) en utilisant votre gestionnaire de paquets. Par exemple, sur CentOS ou Fedora, vous pouvez faire :
    
    ```bash
    bashCopy code
    sudo dnf install firewalld
    
    ```
    
2. Activez Firewalld et démarrez-le avec les commandes suivantes :
    
    ```bash
    bashCopy code
    sudo systemctl start firewalld
    sudo systemctl enable firewalld
    
    ```
    
3. Autorisez l'accès au port que vous souhaitez pour HAProxy (par exemple, le port 80 pour HTTP) en utilisant la commande :
    
    ```bash
    bashCopy code
    sudo firewall-cmd --add-port=80/tcp --permanent
    
    ```
    
4. Si vous utilisez également HTTPS, autorisez le port 443 de la même manière :
    
    ```bash
    bashCopy code
    sudo firewall-cmd --add-port=443/tcp --permanent
    
    ```
    
5. Appliquez les modifications avec :
    
    ```bash
    bashCopy code
    sudo firewall-cmd --reload
    
    ```
    

<aside>
💡 Ces outils, comme UFW et Firewalld, sont conçus pour simplifier la configuration du pare-feu sur Linux et sont souvent préférés par les utilisateurs qui recherchent une approche plus conviviale que la configuration directe d'iptables. Vous pouvez choisir l'outil qui correspond le mieux à vos besoins et à votre distribution Linux spécifique.

</aside>

---

- Configuration de l’ordinateur client:

⇒ Ouvrir l’outil client PostgreSQL sur l’ordinateur distant (PgAdmin ou Psql) et  se connecter à l’adresse IP publique de l’ordinateur serveur PostgreSQL, en utilisant le nom d’utilisateur et le mdp approprié

⇒ Assurer que le pare-feu de l’ordinateur client autorise les connexions sortantes sur le port 5432

(Suite…..)

---