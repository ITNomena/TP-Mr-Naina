# TP-8: Génération Classe

Propriétaire: Nomena Lebreton

<aside>
💡 Objectifs : Créer une génération de `class` basée sur un template (comme ça on peut utiliser que le template à chaque fois qu’on change de langages) en java pour pouvoir générer des classes en fonction des langages : JAVA/C# Sharp/ Annotation (optionnelle)
Moteur Principal pour ce projet : JAVA

</aside>

---

### Architecture des éléments pour la Génération

- Structure de la `Class`
    
    `-Nom`
    
    `-Package`
    
    `-Attribut` (colonnes)
    
    `-Getter/Setter`
    
    `-Annotation` 
    

---

- Structure du Template
    
    <aside>
    📌 Class.Template.templ
    
    </aside>
    
    ##package##   #package#
    
    ##package##   #package#
    
    public class #className#
    

⇒ Les Templates pour gérer les CRUD , les pages , API REST

---

- Structure `Controller`
    
    `-@annontation`
    
    `-methode basique pour un controller` (pour l’instant)
    
- Un `controller` pour chaque langage, pour l’instant on se focalise sur les principaux : **`JAVA` `C# Sharp` `JSP`**
- Chaque `controller` sera rediriger vers un compilateur où il utilisera un moteur pour pouvoir s’excécuter
- Générer `controller` qui retourne un API REST , voir dans Dotnet/Spring Boot pour pouvoir suivre les Templates(moteur)

---

- Créer plusieurs templates pour gérer les CRUD , les pages , API REST

> Un moteur(ou FrameWork) : Dans le cas de Spring Boot ou autre , on doit connaître comment est structuré un `controller` pour pouvoir l’implementer dans le moteur
> 

---

Voici quelques exemples de `controller` communs :

### Spring Boot (JAVA)

@RestController
@RequestMapping("/api")
public class YourController {

```java
@Autowired
private YourService yourService;

@GetMapping("/endpoint")
public ReturnType methodName(@RequestParam("param") String param) {
    // Logique du contrôleur
}

@PostMapping("/endpoint")
public ReturnType methodName(@RequestBody RequestType request) {
    // Logique du contrôleur pour la création
}

@PutMapping("/endpoint/{id}")
public ReturnType methodName(@PathVariable Long id, @RequestBody RequestType request) {
    // Logique du contrôleur pour la mise à jour
}

@DeleteMapping("/endpoint/{id}")
public ReturnType methodName(@PathVariable Long id) {
    // Logique du contrôleur pour la suppression
}

```

}

### **ASP.NET (C#)**

public class YourController : Controller
{
private readonly YourService _yourService;

```csharp
public YourController(YourService yourService)
{
    _yourService = yourService;
}

public IActionResult Index()
{
    // Logique du contrôleur pour afficher une liste
}

public IActionResult Details(int id)
{
    // Logique du contrôleur pour afficher les détails d'un élément
}

public IActionResult Create()
{
    // Logique du contrôleur pour afficher le formulaire de création
}

[HttpPost]
public IActionResult Create([FromBody] RequestType request)
{
    // Logique du contrôleur pour la création
}

public IActionResult Edit(int id)
{
    // Logique du contrôleur pour afficher le formulaire d'édition
}

[HttpPost]
public IActionResult Edit(int id, [FromBody] RequestType request)
{
    // Logique du contrôleur pour la mise à jour
}

public IActionResult Delete(int id)
{
    // Logique du contrôleur pour afficher la confirmation de suppression
}

[HttpPost]
public IActionResult DeleteConfirmed(int id)
{
    // Logique du contrôleur pour la suppression
}

```

}

### Django (Python)

from django.views import View
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse

class YourView(View):
template_name = 'your_template.html'

```python
def get(self, request):
    # Logique du contrôleur pour la requête GET
    return render(request, self.template_name, context)

def post(self, request):
    # Logique du contrôleur pour la requête POST
    return JsonResponse({'key': 'value'})

def put(self, request, pk):
    # Logique du contrôleur pour la requête PUT
    return JsonResponse({'key': 'value'})

def delete(self, request, pk):
    # Logique du contrôleur pour la requête DELETE
    return JsonResponse({'key': 'value'})

```

---

> Méthodes de travail:
> 
- Faire une structure contenant tous les éléments de code nécessaire présent dans une classe :

```java
Bracket-Start = '{'
Bracket-End = '}'
this = 'this'
point = 'point'
Parenthese-start = '('
Parenthese-end = ')'
semicolon = ';'
getter = 'get'
setter = 'set'
Bracket1-Start = '['
Bracket1-End = ']'
```

---

- Configurer aussi les technologies à utiliser dans le Template :

Base de Données ⇒ `Mysql` ou `Postgresql` (Ainsi que le Driver)

Pour les `import` , il n’y a pas d’alternatives mais il faut mettre dans le Template les importations

Bien gérer le structure de la classe d’enregistrement