# TP-S5-S6- Mr Naina

[TP-4 :  Synchronisation Session](TP-4%20Synchronisation%20Session%2053da3e23c0d94dd6aade66970624075f.md)

[TP-3 : Round-Robin](TP-3%20Round-Robin%206a32743748cf479f8f5c94f366f727d0.md)

[TP-5 : SessionHandler](TP-5%20SessionHandler%209c9d8c0c07f34701bd0107decac532d7.md)

[TP-6: Master/Slave](TP-6%20Master%20Slave%20bda4557f07514a549aca0fc4908fd720.csv)

[TP-7: Déploiement d’un Environnement Clusterisé (1)](TP-7%20De%CC%81ploiement%20d%E2%80%99un%20Environnement%20Clusterise%CC%81%20(%204ccc497d23464ed0ae534d1fdafc02a5.md)

[TP-8: Génération Classe](TP-8%20Ge%CC%81ne%CC%81ration%20Classe%20dff5d60ccb904c0fa9ff9a4f46dd4020.md)

[G-Class Project : React Js + Spring Boot API REST](G-Class%20Project%20React%20Js%20+%20Spring%20Boot%20API%20REST%20041ed10b220745a3ab9bc5e9b4952205.md)